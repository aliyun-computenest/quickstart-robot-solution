# 介绍

## 什么是Fluid
Fluid是一个开源的Kubernetes原生的分布式数据集编排和加速引擎，主要服务于云原生场景下的数据密集型应用，例如大数据应用、AI应用等。通过定义数据集资源的抽象，实现如下功能：

![image.png](https://intranetproxy.alipay.com/skylark/lark/0/2021/png/17743/1609837995778-1a3e9139-38cd-4e2f-89dd-3a655151d259.png#align=left&display=inline&height=267&margin=%5Bobject%20Object%5D&name=image.png&originHeight=802&originWidth=1026&size=914368&status=done&style=none&width=342)
## 核心功能

- **数据集抽象原生支持**

将数据密集型应用所需基础支撑能力功能化，实现数据高效访问并降低多维管理成本

- **可扩展的数据引擎插件**

提供统一的访问接口，方便接入第三方存储，通过不同的Runtime实现数据操作

- **自动化的数据操作**

提供多种操作模式，与自动化运维体系相结合

- **数据弹性与调度**

将数据缓存技术和弹性扩缩容、数据亲和性调度能力相结合，提高数据访问性能

- **运行时平台无关**

支持原生、边缘、Serverless Kubernetes集群、Kubernetes多集群等多样化环境，适用于混合云场景

## 重要概念
**Dataset**: 数据集是逻辑上相关的一组数据的集合，会被运算引擎使用，比如大数据的Spark，AI场景的TensorFlow。而这些数据智能的应用会创造工业界的核心价值。Dataset的管理实际上也有多个维度，比如安全性，版本管理和数据加速。我们希望从数据加速出发，对于数据集的管理提供支持。


**Runtime**: 实现数据集安全性，版本管理和数据加速等能力的执行引擎，定义了一系列生命周期的接口。可以通过实现这些接口，支持数据集的管理和加速。

# Release Note
| 版本号     | 变更时间         | 变更内容     |
|---------|--------------|----------|
| `0.7.1` | 2022年03月08日	 | 支持边缘容器场景 |
| `0.8.0` | 2022年08月01日   | (1)支持多副本高可用能力 (2)支持ECI弹性容器实例数据访问场景 (3)支持Jindofsx 4.5.1 |
| `0.8.1` | 2022年08月11日   | 支持Juicefs弹性容器实例数据访问场景 |
| `0.8.2` | 2022年09月02日   | （1）支持JindoFS缓存系统调度至弹性容器实例（2）支持Runtime控制器按需扩容功能（3）支持CRD自动升级 |
| `0.8.3` | 2022年09月14日  | ASK集群环境禁用Application Controller组件 |
| `0.9.0` | 2022年09月21日   | (1)支持Juicefs缓存组件运行于ASK环境 (2)支持ThinRuntime运行时 |
| `0.9.1` | 2022年10月13日   | (1)支持Serverless场景多Dataset PVC挂载（2）Fuse支持污点容忍 |
| `0.9.2` | 2022年11月28日   | (1)支持Webhook objectSelector标签（2）支持通用存储系统容器化接入Fluid（3）支持CSI模式跨Namespace数据集引用访问 |
| `0.9.3` | 2023年01月06日   | (1)支持Sidecar模式跨Namespace数据集引用访问（2）支持Alluxio 2.9.0（3）修复Runtime组件内完整长域名造成的解析问题 (4) 支持控制面组件污点容忍配置 |
| `0.9.4` | 2023年02月02日   | (1) 支持自定义配置JuiceFS访问密钥 （2）支持自定义配置缓存清理超时和重试次数上限 (3) 支持自定义配置Webhook超时上限 |
| `0.9.5` | 2023年02月28日   |（1）默认使用随机策略进行Runtime端口分配（2）支持DataLoad配置ImagePullSecrets |
| `0.9.6` | 2023年03月22日   | (1) 支持DataMigrate数据迁移（2）优化Fluid CSI挂载逻辑（3）DataLoad支持可配置的节点亲和性调度能力 |
| `0.9.7` | 2023年04月06日   | (1) Fluid组件安全加固（2）Alluxio组件模版渲染相关BUG修复 |
| `0.9.8` | 2023年04月18日   | (1) 支持DataMigrate使用PVC作为数据源 （2）支持JindoRuntime设置容器镜像信息（3）支持数据集PVC subPath挂载 |
| `0.9.9` | 2023年04月25日   | (1) JindoRuntime支持环境变量配置 (2)优化Fluid PVC和PV绑定时间 (3)JuiceFSRuntime控制器支持控制器并发度配置 (4)JuiceFSRuntime支持子目录quota配置 (5)修复DataMigrate与DataLoad路径原则不一致问题 |
｜ `0.9.10` | 2023年05月09日 | (1) ASK环境控制面组件资源上调 (2) 支持EFCRuntime |
| `1.0.0` | 2023年06月07日 | （1）JuiceFSRuntime支持定时DataMigrate任务 （2）修复EFCRuntime FUSE Sidecar模式存储卷注入问题 (3) 优化Dataset状态更新逻辑， 加速应用pod启动速度 (4) Runtime部署失败时增加详细错误信息输出 |
| `1.0.1` | 2023年06月19日 | （1）修复Fluid CSI插件残留HostPath挂载点问题 (2) 修复与1.21以下版本Kubernetes兼容性问题（3）增加ARM64节点反亲和调度约束 （4）支持配置是否自动升级CRD |
| `1.0.2` | 2023年07月18日 | （1）Fluid控制面组件安全加固（2）支持ECI实例本地盘作为缓存存储介质（3）支持定时DataLoad缓存预热任务 |
| `1.0.3` | 2023年08月18日 | （1）支持FUSE Sidecar特权挂载模式 （2）修复JuiceFSRuntime控制器OOM问题（3）修复FUSE自动恢复功能相关bug（4）修复升级后Runtime资源残留问题 |
| `1.0.4` | 2023年09月18日 | （1）修复Fluid CSI插件并发问题（2）支持可配置FUSE Sidecar以非阻塞方式启动（3）支持JuiceFSRuntime部分配置动态更新（4）兼容ACK灵骏集群环境部署 |

