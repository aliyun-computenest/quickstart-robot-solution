{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "fluid.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "fluid.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "fluid.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "fluid.labels" -}}
helm.sh/chart: {{ include "fluid.chart" . }}
{{ include "fluid.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "fluid.selectorLabels" -}}
app.kubernetes.io/name: {{ include "fluid.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "fluid.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "fluid.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/* assemble images for fluid control-plane images (ACR EE) */}}
{{- define "fluid.controlplane.imageTransform" -}}
{{- $image := index . 0 -}}
{{- $tag := index . 1 -}}
{{- $isPullImageByVpc := true -}}
{{- $isAppendTag := true -}}
{{- $imagePrefix := "registry-__REGION__.ack.aliyuncs.com" -}}
{{- $region := "" -}}
{{- $argLen := len . -}}
{{- if eq $argLen 5 -}}
{{- $isPullImageByVpc = index . 2 -}}
{{- $isAppendTag = index . 3 -}}
{{- $region = index . 4 -}}
{{- else -}}
{{- fail "fluid.controlplane.imageTransform must have exactly 5 input parameters" -}}
{{- end -}}
{{/* append image prefix*/}}
{{- if eq (len (mustRegexSplit "/" $image -1)) 2 -}}
{{- $image = printf "%s/%s" $imagePrefix $image -}}
{{- end -}}
{{/* append image tag */}}
{{- if and $isAppendTag $tag -}}
{{- $image = printf "%s:%s" $image $tag -}}
{{- end -}}
{{/* replace with region id */}}
{{- $image = $image | replace "__REGION__" $region -}}
{{- if $isPullImageByVpc -}}
"{{ $image | replace ".ack" "-vpc.ack" }}"
{{- else -}}
"{{ $image }}"
{{- end -}}
{{- end -}}

{{/* assemble images for fluid runtime images (ACR)*/}}
{{- define "fluid.runtime.imageTransform" -}}
{{- $image := index . 0 -}}
{{- $tag := index . 1 -}}
{{- $isPullImageByVpc := true -}}
{{- $isAppendTag := true -}}
{{- $imagePrefix := "registry.__REGION__.aliyuncs.com" -}}
{{- $region := "" -}}
{{- $argLen := len . -}}
{{- if eq $argLen 5 -}}
{{- $isPullImageByVpc = index . 2 -}}
{{- $isAppendTag = index . 3 -}}
{{- $region = index . 4 -}}
{{- else -}}
{{- fail "fluid.runtime.imageTransform must have exactly 5 input parameters" -}}
{{- end -}}
{{/* append image prefix*/}}
{{- if eq (len (mustRegexSplit "/" $image -1)) 2 -}}
{{- $image = printf "%s/%s" $imagePrefix $image -}}
{{- end -}}
{{/* append image tag */}}
{{- if and $isAppendTag $tag -}}
{{- $image = printf "%s:%s" $image $tag -}}
{{- end -}}
{{/* replace with region id */}}
{{- $image = $image | replace "__REGION__" $region -}}
{{- if $isPullImageByVpc -}}
"{{ $image | replace "registry." "registry-vpc." }}"
{{- else -}}
"{{ $image }}"
{{- end -}}
{{- end -}}

{{- define "fluid.namespace" -}}
{{- if .Values.namespace -}}
    {{ .Values.namespace }}
{{- else -}}
    {{ .Release.Namespace }}
{{- end -}}
{{- end -}}

{{- define "fluid.controlplane.resources" -}}
{{- if ne .Values.clusterProfileforApp "Serverless" -}}
limits:
  cpu: 100m
  memory: 1536Mi
requests:
  cpu: 100m
  memory: 200Mi
{{- else -}}
limits:
  cpu: 2000m
  memory: 4Gi
requests:
  cpu: 1000m
  memory: 500Mi
{{- end -}}
{{- end -}}

{{- define "fluid.controlplane.affinity" -}}
{{- if ne .Values.clusterProfileforApp "Serverless" -}}
# Either ACK or ACK Edge
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
      - matchExpressions:
        - key: type
          operator: NotIn
          values:
          - virtual-kubelet
        - key: kubernetes.io/arch
          operator: NotIn
          values:
          - "arm64"
        {{- if (eq (.Values.clusterProfileforApp | default "Default") "Edge" )}}
        - key: alibabacloud.com/is-edge-worker
          operator: In
          values: ["false"]
        {{- end }}
        {{- if (eq (.Values.clusterProfileforApp | default "Default") "LingJun")}}
        - key: alibabacloud.com/lingjun-worker
          operator: NotIn
          values: ["true"]
        {{- end }}
{{- else -}}
# ASK
affinity: {}
{{- end -}}
{{- end -}}

{{- define "fluid.helmDriver" -}}
{{- if or (eq .Values.helmDriver "configmap") (eq .Values.helmDriver "secret") -}}
{{ .Values.helmDriver | quote }}
{{- else -}}
{{ fail "helmDriver must be either configmap or secret" }}
{{- end -}}
{{- end -}}

{{- define "fluid.helmDriver.rbacs" -}}
{{- if eq .Values.helmDriver "secret" }}
  - apiGroups:
    - ""
    resources:
    - secrets
    verbs:
    - get
    - list
    - watch
    - create
    - update
    - delete
{{- end -}}
{{- end -}}
