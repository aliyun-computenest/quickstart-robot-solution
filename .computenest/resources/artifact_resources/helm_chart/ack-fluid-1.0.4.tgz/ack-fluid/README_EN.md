# Introduction

## What it Fluid?
Fluid is an open source Kubernetes-native Distributed Dataset Orchestrator and Accelerator for data-intensive applications, such as big data and AI applications. Fluid introduces the following features：

![image.png](https://intranetproxy.alipay.com/skylark/lark/0/2021/png/17743/1609837995778-1a3e9139-38cd-4e2f-89dd-3a655151d259.png#align=left&display=inline&height=267&margin=%5Bobject%20Object%5D&name=image.png&originHeight=802&originWidth=1026&size=914368&status=done&style=none&width=342)

## Features

- **Dataset Abstraction**

Implement the unified abstraction for datasets from multiple storage sources, with observability features to help users evaluate the need for scaling the cache system.

- **Scalable Data Engine**

Offers a unified access interface for data operations with different runtimes, enabling access to third-party storage systems.

- **Automated Data Operations**

Provides various automated data operation modes to facilitate integration with automated operations systems.

- **Elasticity and Scheduling**

By combining data caching technology with elastic scaling, portability, observability, and data affinity scheduling capabilities, Fluid enhances data access performance.

- **Runtime Platform Agnostic**

Supports a variety of environments and can run different storage clients based on the environment, including native, edge, Serverless Kubernetes clusters, and Kubernetes multi-cluster environments.

## Key Concepts

**Dataset**: A DataSet is a set of data logically related that can be used by computing engines, such as Spark for big data analytics and TensorFlow for AI applications. Intelligently leveraging data often creates core industry values. Managing DataSets may require features in different dimensions, such as security, version management and data acceleration. We hope to start with data acceleration to support the management of datasets.

**Runtime**: The execution engine that enforces dataset security, provides version management and data acceleration capabilities. The Runtime defines a set of interfaces to manage DataSets in their life cycle, so the management and acceleration of datasets can be implemented behind these interfaces.


# Release Notes
| Version     | Release date | Release Note |
|---------|--------------|----------|
| `0.7.1` | 2022-03-08	 | (1) Integration with ACK Edge |
| `0.8.0` | 2022-08-01   | (1) Configurable replicas for high availability (2) Support accessing data on ECI Pods (3) Support Jindofsx 4.5.1 |
| `0.8.1` | 2022-08-11   | (1) Support accessing data on ECI pods via JuiceFS |
| `0.8.2` | 2022-09-02   | (1) Support JindoFSx cahce workers running on ECI pods （2）Scale out runtime controllers on demand（3）Auto-upgrade Fluid CRDs |
| `0.8.3` | 2022-09-14  | (1) Disable application controller in ASK |
| `0.9.0` | 2022-09-21   | (1) Support JuiceFS cache workers running on ECI pods (2) Add new ThinRuntime CRD for third-party storage integration |
| `0.9.1` | 2022-10-13   | (1) Support multiple PVC mounts with sidecar mode（2）Configurable tolerations on FUSE pods |
| `0.9.2` | 2022-11-28   | (1) Replace webhook selector with objectSelector（2）Support third-party storage integration（3）Support reference dataset with CSI mode |
| `0.9.3` | 2023-01-06   | (1) Support reference dataset with sidecar mode（2）Support Alluxio 2.9.0（3）Bugfix for DNS resolving with long domain name (4) Configurable tolerations for controllers |
| `0.9.4` | 2023-02-02   | (1) Customized access secrets for JuiceFSRuntime （2）Configurable cache clean policy (3) Configurable webhook timeout |
| `0.9.5` | 2023-02-28   |（1）Allocate ports with random strategy（3）Support specifing imagePullSecrets for DataLoads |
| `0.9.6` | 2023-03-22   | (1) Support DataMigrate（2）Optimize CSI's mounting process（3）Configurable node affinity for DataLoad |
| `0.9.7` | 2023-04-06   | (1) Security issue enhancement（2）bugfix for Helm rendering problem for Alluxio |
| `0.9.8` | 2023-04-18   | (1) Support PVC as a valid data source for DataMigrate （2）Support specifying image info for JindoRuntime（3）Support subPath for PVCs as a Dataset's mountpoint |
| `0.9.9` | 2023-04-25   | (1) Support env variable settings for JindoRuntime(2) Optimize binding process for PVs and PVCs (3) Configurable reconcilation worker num for JuiceFSRuntime (4) Subpath quota feature for JuiceFSRutnime (5) bugfix for path inconsistency between DataLoad and DataMigrate |
｜  `0.9.10` | 2023-05-09 |（1）Setting higher resource requests for controllers in ASK（2）Support EFCRuntime |
｜ `1.0.0` | 2023-06-07 ｜ (1) Support cron DataMigrate for JuiceFSRuntime （2）Fix volume injection when using EFCRuntime in FUSE Sidecar mode （3）Optimize logic when updating dataset status to speed up Pod launching（4）Print detailed error message when failing to set up runtimes |
| `1.0.1` | 2023-06-19 | （1）Fix leaked HostPath mount points in Fluid CSI （2）Fix compatibility with Kubernetes < 1.21 (3) Add anti-affinity requirements to control plane pods to avoid arm64 nodes（4）Support option to enable/disable CRD auto-upgrade |
| `1.0.2` | 2023-07-18 | （1）Fix security issue for Fluid control-plane components（2）Support local SSD(LocalRaid0) as cache storage on ECI instances (3) Support Cron DataLoad |
| `1.0.3` | 2023-08-18 | （1）Support privileged FUSE Sidecar injection（2）Fix Out-of-memory issue for JuiceFSRuntime controller（3）Bugfix for FUSE Recovery（4）Fix orphaned resources issue when upgrading Fluid | 
| `1.0.4` | 2023-09-18 | （1）Fix concurrency issue in Fluid CSI Plugin（2）Support configable launch style for FUSE sidecar（3）Support syncing JuiceFSRuntime spec（4）Support for ACK Lingjun |

